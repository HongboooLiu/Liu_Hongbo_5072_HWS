# comic_home_api

A comic home api package.

## Installation

```bash
$ pip install comic_home_api
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`comic_home_api` was created by Hongbo Liu. It is licensed under the terms of the MIT license.

## Credits

`comic_home_api` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
